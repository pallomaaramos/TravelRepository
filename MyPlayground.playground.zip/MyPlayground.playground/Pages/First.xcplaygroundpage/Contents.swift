import UIKit
import PlaygroundSupport

import AVFoundation


var climate = ""
var language = ""

// Primeira tela: botão de Play

class MyViewController: UIViewController, AVAudioPlayerDelegate {
    
    let play = UIButton()
    
    override func loadView() {
        
        let view = UIView()
        view.backgroundColor = .white
        
        let image = UIImage(named:"persona.png")
        let imageView = UIImageView(image: image)
        imageView.frame = CGRect(x: 831, y: 456, width: 374, height: 272)
        
//        let image3 = UIImage(named:"first.png")
//        let imageView3 = UIImageView(image: image3)
//        imageView3.frame.size = CGSize(width: 1440, height: 900)
        
       let image2 = UIImage(named: "play.png") as UIImage?
        play.frame =  CGRect(x: 428, y: 205, width: 501, height: 501)
        play.setImage(image2, for: .normal)
        
        self.view = view
//        view.addSubview(imageView3)
        view.addSubview(play)
        view.addSubview(imageView)
        
    }
    
    override func viewDidLoad() {
        play.addTarget(self, action: #selector(MyViewController.touchedButton), for: .touchUpInside)
        
    }
    
    @IBAction func touchedButton() {
        navigationController?.pushViewController(secondViewController, animated: true)
    }
    
}


// Segunda Tela: Usuário escolhe a opção desejada de clima e passa para próxima tela

class SecondViewController: UIViewController {
    
    let clima1 = UIButton()
    let clima2 = UIButton()
    //    let prox = UIButton()
    
    override func viewWillAppear(_ animated: Bool) {
        climate = ""
    }
    
    override func loadView() {
        
        
        
        let view = UIView()
        
        let image = UIImage(named:"clima.png")
        let imageView = UIImageView(image: image)
        imageView.frame.size = CGSize(width: 1440, height: 900)
        
        let image2 = UIImage(named: "frio.png") as UIImage?
        clima1.frame =  CGRect(x: 170, y: 320, width: 442, height: 442)
        clima1.setImage(image2, for: .normal)
        clima1.addTarget(self, action: #selector(handleTap1), for: .touchUpInside)
        
        let image3 = UIImage(named: "quente.png") as UIImage?
        clima2.frame =  CGRect(x: 770, y: 320, width: 442, height: 442)
        clima2.setImage(image3, for: .normal)
        clima2.addTarget(self, action: #selector(handleTap2), for: .touchUpInside)
        
        //        let proximo = UIImage(named:"next.png")
        //        prox.frame = CGRect(x:1140,y:105,width: 154, height: 154)
        //        prox.setImage(proximo, for: .normal)
        //
        //        prox.addTarget(self, action: #selector(handleTap), for: .touchUpInside)
        
        
        self.view = view
        view.addSubview(imageView)
        //        view.addSubview(prox)
        view.addSubview(clima1)
        view.addSubview(clima2)
        
        
    }
    
    @IBAction func handleTap1() {
        climate = "frio"
        navigationController?.pushViewController(FourthViewController(), animated: true)
        
    }
    @IBAction func handleTap2() {
        climate = "quente"
        navigationController?.pushViewController(FourthViewController(), animated: true)
        
    }
    
}
class FourthViewController : UIViewController{
    
    //    let prox = UIButton()
    let ing = UIButton()
    let fran = UIButton()
    let esp = UIButton()
    let port = UIButton()
    
    override func viewWillAppear(_ animated: Bool) {
        language = ""
    }
    
    override func loadView() {
        
        
        let view = UIView()
        
        let image = UIImage(named:"lingua.png")
        let imageView = UIImageView(image: image)
        imageView.frame.size = CGSize(width: 1460, height: 900)
        
        //        let proximo = UIImage(named:"next.png")
        //        prox.frame = CGRect(x:1140,y:105,width: 154, height: 154)
        //        prox.setImage(proximo, for: .normal)
        //        prox.addTarget(self, action: #selector(handleTap), for: .touchUpInside)
        
        let image1 = UIImage(named: "ingles-2.png") as UIImage?
        ing.frame =  CGRect(x: 215, y: 358, width: 246, height: 171)
        ing.setImage(image1, for: .normal)
        ing.addTarget(self, action: #selector(handleTap1), for: .touchUpInside)
        
        let image2 = UIImage(named: "frances-2.png") as UIImage?
        fran.frame =  CGRect(x: 999, y: 479, width: 246, height: 169)
        fran.setImage(image2, for: .normal)
        fran.addTarget(self, action: #selector(handleTap2), for: .touchUpInside)
        
        let image3 = UIImage(named: "espanhol-3.png") as UIImage?
        esp.frame =  CGRect(x: 461, y: 509, width: 302, height: 208)
        esp.setImage(image3, for: .normal)
        esp.addTarget(self, action: #selector(handleTap3), for: .touchUpInside)
        
        let image4 = UIImage(named: "portugues-2.png") as UIImage?
        port.frame =  CGRect(x: 729, y: 310, width: 326, height: 212)
        port.setImage(image4, for: .normal)
        port.addTarget(self, action: #selector(handleTap4), for: .touchUpInside)
        
        
        self.view = view
        view.addSubview(imageView)
        view.addSubview(ing)
        view.addSubview(fran)
        view.addSubview(esp)
        view.addSubview(port)
        //        view.addSubview(prox)
        
    }
    
    @IBAction func handleTap1() {
        language = "ingles"
        
        navigationController?.pushViewController(TransporteViewController(), animated: true)
    }
    @IBAction func handleTap2() {
        language = "frances"
        
        navigationController?.pushViewController(TransporteViewController(), animated: true)
        
    }
    @IBAction func handleTap3() {
        language = "espanhol"
        
        navigationController?.pushViewController(TransporteViewController(), animated: true)
        
    }
    @IBAction func handleTap4() {
        language = "portugues"
        
        navigationController?.pushViewController(TransporteViewController(), animated: true)
        
    }
}

var transporte = ""

class TransporteViewController: UIViewController{
    let aviao = UIButton()
    let carro = UIButton()
    let navio = UIButton()
    
    override func viewWillAppear(_ animated: Bool) {
        transporte = ""
    }
    
    override func loadView() {
        
        
        let view = UIView()
        
        let image = UIImage(named:"transporte.png")
        let imageView = UIImageView(image: image)
        imageView.frame.size = CGSize(width: 1460, height: 900)
        
        let image1 = UIImage(named: "aviao.png") as UIImage?
        aviao.frame =  CGRect(x: 81, y: 320, width: 391, height: 391)
        aviao.setImage(image1, for: .normal)
        aviao.addTarget(self, action: #selector(handleTap1), for: .touchUpInside)
        
        let image2 = UIImage(named: "carro.png") as UIImage?
        carro.frame =  CGRect(x: 523, y: 320, width: 391, height: 391)
        carro.setImage(image2, for: .normal)
        carro.addTarget(self, action: #selector(handleTap2), for: .touchUpInside)
        
        let image3 = UIImage(named: "navio.png") as UIImage?
        navio.frame =  CGRect(x: 986, y: 320, width: 391, height: 391)
        navio.setImage(image3, for: .normal)
        navio.addTarget(self, action: #selector(handleTap3), for: .touchUpInside)
        
        self.view = view
        view.addSubview(imageView)
        view.addSubview(aviao)
        view.addSubview(carro)
        view.addSubview(navio)
    }
    @IBAction func handleTap1() {
        transporte = "aviao"
        navigationController?.pushViewController(GastosViewController(), animated: true)
    }
    @IBAction func handleTap2() {
        transporte = "carro"
        navigationController?.pushViewController(GastosViewController(), animated: true)
        
    }
    @IBAction func handleTap3() {
        transporte = "navio"
        navigationController?.pushViewController(GastosViewController(), animated: true)
        
    }
}

var gastos = ""

class GastosViewController: UIViewController{
    let pouco = UIButton()
    let medio = UIButton()
    let muito = UIButton()
    
    override func viewWillAppear(_ animated: Bool) {
        gastos = ""
    }
    
    override func loadView() {
        
        
        let view = UIView()
        
        let image = UIImage(named:"gastos.png")
        let imageView = UIImageView(image: image)
        imageView.frame.size = CGSize(width: 1460, height: 900)
        
        let image1 = UIImage(named: "pouco.png") as UIImage?
        pouco.frame =  CGRect(x: 82.5, y: 308, width: 391, height: 447)
        pouco.setImage(image1, for: .normal)
        pouco.addTarget(self, action: #selector(handleTap1), for: .touchUpInside)
        
        let image2 = UIImage(named: "medio.png") as UIImage?
        medio.frame =  CGRect(x: 501.5, y: 303, width: 452, height: 452)
        medio.setImage(image2, for: .normal)
        medio.addTarget(self, action: #selector(handleTap2), for: .touchUpInside)
        
        let image3 = UIImage(named: "muito.png") as UIImage?
        muito.frame =  CGRect(x: 957.5, y: 308, width: 523, height: 442)
        muito.setImage(image3, for: .normal)
        muito.addTarget(self, action: #selector(handleTap3), for: .touchUpInside)
        
        self.view = view
        view.addSubview(imageView)
        view.addSubview(pouco)
        view.addSubview(medio)
        view.addSubview(muito)
        
    }
    @IBAction func handleTap1() {
        gastos = "pouco"
        
        navigationController?.pushViewController(ThirdViewController(), animated: true)
        
        
    }
    @IBAction func handleTap2() {
        gastos = "medio"
        
        navigationController?.pushViewController(ThirdViewController(), animated: true)
        
    }
    @IBAction func handleTap3() {
        gastos = "muito"
        
        navigationController?.pushViewController(ThirdViewController(), animated: true)
        
    }
}
// Terceira Tela: Aparecem as opções de lugares com base no que foi escolhido anteriormente

class ThirdViewController: UIViewController{
    
    let info = UIButton()
    let info2 = UIButton()
    let info3 = UIButton()
    
    override func viewWillAppear(_ animated: Bool) {
        climate = ""
        language = ""
    }
    
    override func loadView() {
        let view = UIView()
        view.frame.size = CGSize(width: 1440, height:900)
        view.backgroundColor = #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)
        
        let flagC = UIImage(named:"destinoC.png")
        let flagCView = UIImageView(image: flagC)
        flagCView.frame = CGRect(x: 83, y: 330, width: 302, height: 302)
        
        let flagB = UIImage(named:"destinoB.png")
        let flagBView = UIImageView(image: flagB)
        flagBView.frame = CGRect(x: 541, y: 330, width: 302, height: 302)
        
        let flagE = UIImage(named:"destinoE.png")
        let flagEView = UIImageView(image: flagE)
        flagEView.frame = CGRect(x: 983, y: 330, width: 302, height: 302)
        
        
        let image = UIImage(named:"resultado.png")
        let imageView = UIImageView(image: image)
        imageView.frame.size = CGSize(width: 1440, height: 900)
        
        let imageh = UIImage(named:"Espanha.png")
        let imageView2 = UIImageView(image: imageh)
        imageView2.frame = CGRect(x: 1036, y: 654, width: 194, height: 70)
        
        let imageb = UIImage(named:"Brasil.png")
        let imageView4 = UIImageView(image: imageb)
        imageView4.frame = CGRect(x: 620, y: 654, width: 144, height: 60)
        
        let imagec = UIImage(named:"Canadá.png")
        let imageView3 = UIImageView(image: imagec)
        imageView3.frame = CGRect(x: 136, y: 654, width: 189, height: 60)
        
        let infos = UIImage(named:"infos.png")
        info.frame = CGRect(x:346,y:665,width: 40, height: 48)
        info.setImage(infos, for: .normal)
        info.addTarget(self, action: #selector(handleTap), for: .touchUpInside)
        
        info2.frame = CGRect(x:799,y:665,width: 40, height: 48)
        info2.setImage(infos, for: .normal)
        info2.addTarget(self, action: #selector(handleTap2), for: .touchUpInside)
        
        info3.frame = CGRect(x:1258,y:665,width: 40, height: 48)
        info3.setImage(infos, for: .normal)
        info3.addTarget(self, action: #selector(handleTap3), for: .touchUpInside)
        
        
        if (climate == "frio" && language == "ingles" && transporte == "aviao" && gastos == "muito" || climate == "quente" && language == "frances" && transporte == "aviao" && gastos == "muito" ) {
            
            flagEView.isHidden = true
            flagBView.isHidden = true
            imageView4.isHidden = true
            imageView2.isHidden = true
            info2.isHidden = true
            info3.isHidden = true
            flagCView.frame = CGRect(x: 541, y: 330, width: 302, height: 302)
            imageView3.frame = CGRect(x: 620, y: 654, width: 189, height: 60)
            info.frame = CGRect(x:850,y:665,width: 40, height: 48)
            
        } else if climate == "quente" && language == "portugues" {
            imageView2.isHidden = true
            imageView3.isHidden = true
            info3.isHidden = true
            info.isHidden = true
            flagEView.isHidden = true
            flagCView.isHidden = true
            
            
        } else if climate == "quente" && language == "espanhol" {
            imageView3.isHidden = true
            imageView4.isHidden = true
            flagCView.isHidden = true
            flagBView.isHidden = true
            info.isHidden = true
            info2.isHidden = true
            flagEView.frame = CGRect(x: 541, y: 330, width: 302, height: 302)
            imageView2.frame = CGRect(x: 620, y: 654, width: 189, height: 60)
            info3.frame = CGRect(x:850,y:665,width: 40, height: 48)
        }
        else {
            
        }
        
        
        self.view = view
        view.addSubview(imageView)
        view.addSubview(imageView2)
        view.addSubview(imageView3)
        view.addSubview(imageView4)
        view.addSubview(flagBView)
        view.addSubview(flagCView)
        view.addSubview(flagEView)
        view.addSubview(info)
        view.addSubview(info2)
        view.addSubview(info3)
        
    }
    
    @IBAction func handleTap2() {
        navigationController?.pushViewController(brasilViewController, animated: true)  }
    
    @IBAction func handleTap() {
        navigationController?.pushViewController(canadaViewController, animated: true)  }
    
    @IBAction func handleTap3() {
    }
    
    
}

class CanadaViewController: UIViewController,UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {
    
    let viewInfo = UIView()
    let infoButton = UIButton()
    
    let fotos: [UIImage] = [UIImage(named: "d.png")!, UIImage(named: "c.png")!, UIImage(named: "b.png")!, UIImage(named: "a.png")!]
    
    let collectionView = UICollectionView(frame: CGRect(x: 120, y: 330, width: 1200, height: 450), collectionViewLayout: UICollectionViewFlowLayout())
    
    override func loadView() {
        let view = UIView()
        view.frame.size = CGSize(width: 1440, height:1100)
        
        let image = UIImage(named:"canadatela.png")
        let imageView = UIImageView(image: image)
        imageView.frame.size = CGSize(width: 1440, height: 900)
        
        infoButton.frame = CGRect(x: 1102, y: 90, width: 47, height: 52)
        infoButton.setBackgroundImage(UIImage(named: "infos2"), for: .normal)
        
        let infos = UIImageView(image: UIImage(named: "image 5-2.png"))
        infos.frame = CGRect(x: 465, y: 174, width: 541, height: 637)
        let viewBackground = UIView()
        viewBackground.backgroundColor = #colorLiteral(red: 0, green: 0, blue: 0, alpha: 0.4)
        viewBackground.frame.size = CGSize(width: 1440, height: 900)
        
        let tap = UITapGestureRecognizer(target: self, action: #selector(handleTap))
        
        viewBackground.addGestureRecognizer(tap)
        
        viewInfo.frame.size = CGSize(width: 1440, height: 900)
        viewInfo.addSubview(viewBackground)
        viewInfo.addSubview(infos)
        viewInfo.alpha = 0
        viewInfo.isHidden = false
        
        //collection view
        collectionView.register(TesteCollectionViewCell.self, forCellWithReuseIdentifier: "Cell")
        if let layout = collectionView.collectionViewLayout as? UICollectionViewFlowLayout {
            layout.scrollDirection = .horizontal }
        collectionView.backgroundColor = #colorLiteral(red: 0.9607843137, green: 0.9607843137, blue: 0.9607843137, alpha: 1)
        
        //        let scrollView = UIScrollView()
        //        scrollView.contentSize = view.frame.size
        //        scrollView.flashScrollIndicators()
        //        scrollView.backgroundColor = .white
        
        self.view = view
        view.addSubview(imageView)
        view.addSubview(collectionView)
        view.addSubview(infoButton)
        view.addSubview(viewInfo)
        
        //        scrollView.addSubview(view)
        //        self.view = scrollView
        //                self.view = view
        infoButton.addTarget(self, action: #selector(CanadaViewController.infoTouched), for: .touchUpInside)
    }
    
    @IBAction func infoTouched() {
        viewInfo.isHidden = false
        UIView.animate(withDuration: 0.3) {
            self.viewInfo.alpha = 1
        }
    }
    @objc func handleTap(_ gesture: UIGestureRecognizer) {
        UIView.animate(withDuration: 0.3, animations: {
            self.viewInfo.alpha = 0
        }) { _ in
            self.viewInfo.isHidden = true
        }
    }
    override func viewDidLoad() {
        collectionView.delegate = self
        collectionView.dataSource = self
        
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: 684, height: 450)
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return fotos.count
    }
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "Cell", for: indexPath) as? TesteCollectionViewCell
        cell?.backgroundView = UIImageView(image: fotos[indexPath.item])
        
        return cell!
    }
    
    
}

class TesteCollectionViewCell: UICollectionViewCell{
    
}

var image = UIImage()
var toque = ""

class BrasilViewController: UIViewController {
    
    let viewInfo = UIView()
    let infoButton = UIButton()
    
    let imageView2 = UIImageView(image: UIImage(named:"transparente.png"))
    
    let imageView3 = UIImageView(image: UIImage(named:"centro-oeste.png"))
    
    override func viewWillAppear(_ animated: Bool) {
        toque = ""
    }
    override func loadView() {
        
        
        let view = UIView()
        view.frame.size = CGSize(width: 1440, height:1100)
        
        let image = UIImage(named:"brasilTela.png")
        let imageView = UIImageView(image: image)
        imageView.frame.size = CGSize(width: 1470, height: 900)
        
        imageView2.frame = CGRect(x: 802, y: 423, width: 177, height: 140)
        imageView2.isUserInteractionEnabled = true
        imageView2.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(self.handleTap(_:))))
        
        imageView3.frame = CGRect(x: 570, y: 495.5, width: 228, height: 232)
        imageView3.isUserInteractionEnabled = true
        let tap3 = UITapGestureRecognizer(target: self, action: #selector(self.handleTap))
        imageView3.addGestureRecognizer(tap3)
        
        
        infoButton.frame = CGRect(x: 1102, y: 90, width: 47, height: 52)
        infoButton.setBackgroundImage(UIImage(named: "infos2"), for: .normal)
        
        let infos = UIImageView(image: UIImage(named: "image 6.png"))
        infos.frame = CGRect(x: 465, y: 174, width: 541, height: 637)
        let viewBackground = UIView()
        viewBackground.backgroundColor = #colorLiteral(red: 0, green: 0, blue: 0, alpha: 0.4)
        viewBackground.frame.size = CGSize(width: 1440, height: 900)
        
        let tap2 = UITapGestureRecognizer(target: self, action: #selector(handleTap2))
        
        viewBackground.addGestureRecognizer(tap2)
        
        viewInfo.frame.size = CGSize(width: 1440, height: 900)
        viewInfo.addSubview(viewBackground)
        viewInfo.addSubview(infos)
        viewInfo.alpha = 0
        viewInfo.isHidden = false
        
        self.view = view
        view.addSubview(imageView)
        view.addSubview(imageView2)
        view.addSubview(imageView3)
        view.addSubview(infoButton)
        view.addSubview(viewInfo)
        
        infoButton.addTarget(self, action: #selector(BrasilViewController.infoTouched), for: .touchUpInside)
    }
    
    @IBAction func infoTouched() {
        viewInfo.isHidden = false
        UIView.animate(withDuration: 0.3) {
            self.viewInfo.alpha = 1
        }
    }
    @objc func handleTap2(_ gesture: UIGestureRecognizer) {
        UIView.animate(withDuration: 0.3, animations: {
            self.viewInfo.alpha = 0
        }) { _ in
            self.viewInfo.isHidden = true
        }
    }
    
    @objc func handleTap(_ gesture: UITapGestureRecognizer) {
        
        if gesture.view == imageView2 {
            
            toque = "nordeste"
            
        }
        else {
            toque = "centro-oeste"
        }
        navigationController?.pushViewController(RegiaoViewController(), animated: true)
        
    }
}
class RegiaoViewController: UIViewController,UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {
    
    
    var fotos = [UIImage()]
    
    let collectionView = UICollectionView(frame: CGRect(x: 120, y: 200, width: 1200, height: 606), collectionViewLayout: UICollectionViewFlowLayout())
    
    override func loadView() {
        
        let view = UIView()
        view.frame.size = CGSize(width: 1440, height:1100)
        view.backgroundColor = #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)
        
        var image = UIImage(named:"")
        
        if toque == "nordeste" {
            
            fotos = [UIImage(named: "1.png")!, UIImage(named: "2.png")!, UIImage(named: "3.png")!, UIImage(named: "4.png")!,UIImage(named: "5.png")!,UIImage(named: "6.png")!]
            
            image = UIImage(named:"nordeste.png")
        }
        else if toque == "centro-oeste" {
            fotos = [UIImage(named: "11.png")!, UIImage(named: "12.png")!, UIImage(named: "13.png")!, UIImage(named: "14.png")!]
            
            image = UIImage(named:"centro.png")
        }
        else {}
        
        let imageView = UIImageView(image: image)
        imageView.frame.size = CGSize(width: 1440, height: 900)
        
        //collection view
        collectionView.register(TesteCollectionViewCell.self, forCellWithReuseIdentifier: "Cell")
        if let layout = collectionView.collectionViewLayout as? UICollectionViewFlowLayout {
            layout.scrollDirection = .horizontal }
        collectionView.backgroundColor = #colorLiteral(red: 0.9607843137, green: 0.9607843137, blue: 0.9607843137, alpha: 1)
        
        //        let scrollView = UIScrollView()
        //        scrollView.contentSize = view.frame.size
        //        scrollView.flashScrollIndicators()
        //        scrollView.backgroundColor = .white
        
        self.view = view
        
        view.addSubview(imageView)
        view.addSubview(collectionView)
        
        
    }
    
    override func viewDidLoad() {
        collectionView.delegate = self
        collectionView.dataSource = self
        
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: 1015, height: 606)
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return fotos.count
    }
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "Cell", for: indexPath) as? TesteCollectionViewCell
        cell?.backgroundView = UIImageView(image: fotos[indexPath.item])
        
        return cell!
    }
}


// Faz com que todas as telas tenham o mesmo tamanho e passe de uma para outra



let firstViewController = MyViewController()
let secondViewController = SecondViewController()
let thirdViewController = ThirdViewController()
let fourthViewController = FourthViewController()
let canadaViewController = CanadaViewController()
let brasilViewController = BrasilViewController()
let regiaoVC = RegiaoViewController()
let transporteVC = TransporteViewController()

let navigation = UINavigationController(screenType: .mac, isPortrait: true)
navigation.navigationBar.isHidden = false
navigation.navigationBar.barTintColor = .white
navigation.pushViewController(firstViewController, animated: true)

let navigation2 = UINavigationController(screenType: .mac, isPortrait: true)
navigation2.navigationBar.isHidden = false
navigation2.navigationBar.barTintColor = .white
navigation2.pushViewController(thirdViewController, animated: true)




let categorias = navigation
let destinos = navigation2

categorias.title = "Categorias"
destinos.title = "Destinos"

let viewControllers = [ /* suas telas */
    categorias, destinos]


let tabBarController = UITabBarController(/*específico do meu projeto*/screenType: .mac)
tabBarController.viewControllers = viewControllers
tabBarController.tabBar.barTintColor = #colorLiteral(red: 0.9820129275, green: 0.9296342731, blue: 0.720338285, alpha: 1)

UITabBarItem.appearance()
    .setTitleTextAttributes(
        [NSAttributedString.Key.font: UIFont.systemFont(ofSize: 35)],
        for: .normal)


PlaygroundPage.current.liveView = tabBarController.scale(to: 0.4)

